<?php
	function databaseConnection(){    
		$servername = "localhost";
		$username = "root";
		$password = "";
		$dbname = "pgdit";
		// Create connection
		$conn = mysqli_connect($servername, $username, $password, $dbname);
			// Check connection
		if (!$conn) {
			echo "Connection failed: " . mysqli_connect_error();
			return null;
		}		
		return $conn;
	}
	function updateTestimonialInfo() {
		$conn = databaseConnection();
		$stdid = '5';
		$user = $_SESSION["myusername"];
		$stmt = "update testimonial_info set is_issued='Y', issued_by=$user where std_sl = $stdid";
		$result = mysqli_query($conn, $stmt);		
		
		if (mysqli_query($conn, $stmt)) {
			echo 'Data updated successfully. ';
		} else {
			echo 'No data Updated.';
		}
	}
?> 