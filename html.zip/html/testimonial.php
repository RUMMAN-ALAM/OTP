<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "pgdit";
	$tbl_name="user_info"; // Table name 

	// Create connection
	$conn = mysqli_connect($servername, $username, $password, $dbname);
?>
<html>
	<head>
		<title>Testimonial Print</title>
		<style>
			.container {
				position:relative,
			}
			.top {
				text-align: center;
				top: 10%;
				left: 50%;
				transform: translate(-50%,10%);
				position: absolute;
			}
			.top h2 {
				text-transform: uppercase;
				letter-spacing: 8px;
				padding: 2px;
				margin: 0px;
			}
			.top h4 {
				padding: 2px;
				margin: 0px;
			}
			.tbody {
				top: 30%;
				left: 50%;
				text-align: center;
				position: absolute;
				transform: translate(-50%,30%);
			}
		</style>
	</head>
	<body>
		<div class="container">
			<div class="top">
				<h2>Your Institute Name</h2>
				<h4>Institute address</h4><br/>
				<div><h2>Testimonial</h2></div>
			</div>
			<div class="tbody">This is to certify that, </div>
			
		</div>
	</body>
</html>